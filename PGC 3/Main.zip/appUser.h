char appUser(produto[], int,int *, int*, int);
void Pedido(produto[], int,int *, int*);
bool Pagamento(produto[], int, int*, int*, int);
