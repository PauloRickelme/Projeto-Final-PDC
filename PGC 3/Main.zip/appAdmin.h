char appAdmin(produto [],int);
void Adicionar(produto[], int);
void Excluir(produto[], int);
void Listar(produto [],int);